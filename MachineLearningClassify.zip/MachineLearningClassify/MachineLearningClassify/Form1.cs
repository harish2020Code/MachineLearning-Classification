﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace MachineLearningClassify
{
    public partial class Form1 : Form
    {
        public string TrainFileLocation;
        public string TestFileLocation;
        public string ModelLocation;
        public Form1()
        {
            InitializeComponent();
            txtBuildStatus.Text = "";
        }

        private void btnBrowseTrainDtLocal_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileTrainData.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                TrainFileLocation = openFileTrainData.FileName;
                txtBoxTrainData.Text = TrainFileLocation;
            }
        }
        private void btnBrowseTestDtLocal_Click(object sender, EventArgs e)
        {
            
            DialogResult result = openFileTestData.ShowDialog();
            if (result == DialogResult.OK)  
            {
                TestFileLocation = openFileTestData.FileName;
                txtBoxTestData.Text = TestFileLocation;
            }
        }
       
        private void btnBuildModel_Click(object sender, EventArgs e)
        {
            txtBuildStatus.Text = "Started";
            Classify MLC = new Classify()
            {
                _trainDataPath = TrainFileLocation,
                _testDataPath = TestFileLocation,
                // TBD to for dynamic
                _modelPath = txtSaveModelLocation.Text +  @"\Model.zip"
            };
            if (!string.IsNullOrEmpty(TrainFileLocation) && !string.IsNullOrEmpty(TestFileLocation))
            {
                txtBuildStatus.Text = "Inprogress";
                string result = MLC.BuildTrainAndEvaluateModel();
                txtBuildStatus.Text = result;
            }
            else
            {
                MessageBox.Show("Please select Train and Test Data file");
            }
        }

        private void btnSBrowseModelFolder_Click(object sender, EventArgs e)
        {
            DialogResult result = openFolderModelLocation.ShowDialog();
            if (result == DialogResult.OK)  
            {
                ModelLocation = openFolderModelLocation.SelectedPath;
                txtSaveModelLocation.Text = ModelLocation;
            }
        }

        private void btnGetDoctype_Click(object sender, EventArgs e)
        {
            Classify MLC = new Classify();
            if(!string.IsNullOrEmpty(txtOcrData.Text) && !string.IsNullOrEmpty(txtSelectedModel.Text))
            {
                DocTypePrediction predictionResult = MLC.PredictDocType(txtOcrData.Text, txtSelectedModel.Text); // Pass OCR data and get result
                txtDocType.Text = predictionResult.DocType;
                txtConfidence.Text = Convert.ToString(predictionResult.Score.Max() * 100);
            }
            else
            {
                MessageBox.Show("Please input OCR data and select the model ");
            }
            
        }

        private void btnSelectModel_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileModel.ShowDialog();
            if (result == DialogResult.OK)
            {
                ModelLocation = openFileModel.FileName;
                txtSelectedModel.Text = ModelLocation;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtOcrData.Text = "";
            txtSelectedModel.Text = "";
        }

        private void btnResetBuildModelPage_Click(object sender, EventArgs e)
        {
            txtBoxTestData.Text = "";
            txtBoxTrainData.Text = "";
            txtBuildStatus.Text = "";
            txtSaveModelLocation.Text = "";
        }
    }
}
