﻿namespace MachineLearningClassify
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtOcrData = new System.Windows.Forms.TextBox();
            this.lblOcrData = new System.Windows.Forms.Label();
            this.lblDoctype = new System.Windows.Forms.Label();
            this.txtDocType = new System.Windows.Forms.TextBox();
            this.lblConfidence = new System.Windows.Forms.Label();
            this.txtConfidence = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnResetGetDocTypePage = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtSaveModelLocation = new System.Windows.Forms.TextBox();
            this.btnSBrowseModelFolder = new System.Windows.Forms.Button();
            this.lblModelStorePath = new System.Windows.Forms.Label();
            this.txtBoxTestData = new System.Windows.Forms.TextBox();
            this.txtBoxTrainData = new System.Windows.Forms.TextBox();
            this.btnBrowseTestDtLocal = new System.Windows.Forms.Button();
            this.btnBrowseTrainDtLocal = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBuildStatus = new System.Windows.Forms.TextBox();
            this.btnBuildModel = new System.Windows.Forms.Button();
            this.LblTestDataLocation = new System.Windows.Forms.Label();
            this.lblTrainDataLocation = new System.Windows.Forms.Label();
            this.openFileTrainData = new System.Windows.Forms.OpenFileDialog();
            this.openFileTestData = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.openFolderModelLocation = new System.Windows.Forms.FolderBrowserDialog();
            this.btnGetDoctype = new System.Windows.Forms.Button();
            this.lblModelPath = new System.Windows.Forms.Label();
            this.btnSelectModel = new System.Windows.Forms.Button();
            this.openFileModel = new System.Windows.Forms.OpenFileDialog();
            this.txtSelectedModel = new System.Windows.Forms.TextBox();
            this.btnResetBuildModelPage = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtOcrData
            // 
            this.txtOcrData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOcrData.Location = new System.Drawing.Point(37, 56);
            this.txtOcrData.Multiline = true;
            this.txtOcrData.Name = "txtOcrData";
            this.txtOcrData.Size = new System.Drawing.Size(634, 135);
            this.txtOcrData.TabIndex = 2;
            // 
            // lblOcrData
            // 
            this.lblOcrData.AutoSize = true;
            this.lblOcrData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOcrData.Location = new System.Drawing.Point(34, 40);
            this.lblOcrData.Name = "lblOcrData";
            this.lblOcrData.Size = new System.Drawing.Size(54, 13);
            this.lblOcrData.TabIndex = 3;
            this.lblOcrData.Text = "OcrData";
            // 
            // lblDoctype
            // 
            this.lblDoctype.AutoSize = true;
            this.lblDoctype.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoctype.Location = new System.Drawing.Point(212, 271);
            this.lblDoctype.Name = "lblDoctype";
            this.lblDoctype.Size = new System.Drawing.Size(96, 13);
            this.lblDoctype.TabIndex = 4;
            this.lblDoctype.Text = "Document Type";
            // 
            // txtDocType
            // 
            this.txtDocType.Enabled = false;
            this.txtDocType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocType.Location = new System.Drawing.Point(325, 271);
            this.txtDocType.Name = "txtDocType";
            this.txtDocType.Size = new System.Drawing.Size(100, 20);
            this.txtDocType.TabIndex = 5;
            // 
            // lblConfidence
            // 
            this.lblConfidence.AutoSize = true;
            this.lblConfidence.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfidence.Location = new System.Drawing.Point(466, 272);
            this.lblConfidence.Name = "lblConfidence";
            this.lblConfidence.Size = new System.Drawing.Size(71, 13);
            this.lblConfidence.TabIndex = 6;
            this.lblConfidence.Text = "Confidence";
            // 
            // txtConfidence
            // 
            this.txtConfidence.Enabled = false;
            this.txtConfidence.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfidence.Location = new System.Drawing.Point(569, 271);
            this.txtConfidence.Name = "txtConfidence";
            this.txtConfidence.Size = new System.Drawing.Size(100, 20);
            this.txtConfidence.TabIndex = 7;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(51, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(713, 379);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtSelectedModel);
            this.tabPage1.Controls.Add(this.btnSelectModel);
            this.tabPage1.Controls.Add(this.lblModelPath);
            this.tabPage1.Controls.Add(this.btnGetDoctype);
            this.tabPage1.Controls.Add(this.btnResetGetDocTypePage);
            this.tabPage1.Controls.Add(this.txtOcrData);
            this.tabPage1.Controls.Add(this.txtConfidence);
            this.tabPage1.Controls.Add(this.lblConfidence);
            this.tabPage1.Controls.Add(this.lblOcrData);
            this.tabPage1.Controls.Add(this.txtDocType);
            this.tabPage1.Controls.Add(this.lblDoctype);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(705, 353);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Get DocType";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnResetGetDocTypePage
            // 
            this.btnResetGetDocTypePage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetGetDocTypePage.Location = new System.Drawing.Point(291, 321);
            this.btnResetGetDocTypePage.Name = "btnResetGetDocTypePage";
            this.btnResetGetDocTypePage.Size = new System.Drawing.Size(75, 23);
            this.btnResetGetDocTypePage.TabIndex = 8;
            this.btnResetGetDocTypePage.Text = "Reset";
            this.btnResetGetDocTypePage.UseVisualStyleBackColor = true;
            this.btnResetGetDocTypePage.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnResetBuildModelPage);
            this.tabPage2.Controls.Add(this.txtSaveModelLocation);
            this.tabPage2.Controls.Add(this.btnSBrowseModelFolder);
            this.tabPage2.Controls.Add(this.lblModelStorePath);
            this.tabPage2.Controls.Add(this.txtBoxTestData);
            this.tabPage2.Controls.Add(this.txtBoxTrainData);
            this.tabPage2.Controls.Add(this.btnBrowseTestDtLocal);
            this.tabPage2.Controls.Add(this.btnBrowseTrainDtLocal);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtBuildStatus);
            this.tabPage2.Controls.Add(this.btnBuildModel);
            this.tabPage2.Controls.Add(this.LblTestDataLocation);
            this.tabPage2.Controls.Add(this.lblTrainDataLocation);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(705, 353);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Build Model";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtSaveModelLocation
            // 
            this.txtSaveModelLocation.Location = new System.Drawing.Point(318, 138);
            this.txtSaveModelLocation.Multiline = true;
            this.txtSaveModelLocation.Name = "txtSaveModelLocation";
            this.txtSaveModelLocation.Size = new System.Drawing.Size(342, 44);
            this.txtSaveModelLocation.TabIndex = 13;
            // 
            // btnSBrowseModelFolder
            // 
            this.btnSBrowseModelFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSBrowseModelFolder.Location = new System.Drawing.Point(206, 139);
            this.btnSBrowseModelFolder.Name = "btnSBrowseModelFolder";
            this.btnSBrowseModelFolder.Size = new System.Drawing.Size(75, 23);
            this.btnSBrowseModelFolder.TabIndex = 12;
            this.btnSBrowseModelFolder.Text = "Browse";
            this.btnSBrowseModelFolder.UseVisualStyleBackColor = true;
            this.btnSBrowseModelFolder.Click += new System.EventHandler(this.btnSBrowseModelFolder_Click);
            // 
            // lblModelStorePath
            // 
            this.lblModelStorePath.AutoSize = true;
            this.lblModelStorePath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModelStorePath.Location = new System.Drawing.Point(42, 139);
            this.lblModelStorePath.Name = "lblModelStorePath";
            this.lblModelStorePath.Size = new System.Drawing.Size(127, 13);
            this.lblModelStorePath.TabIndex = 11;
            this.lblModelStorePath.Text = "Save Model Location";
            // 
            // txtBoxTestData
            // 
            this.txtBoxTestData.Enabled = false;
            this.txtBoxTestData.Location = new System.Drawing.Point(318, 86);
            this.txtBoxTestData.Multiline = true;
            this.txtBoxTestData.Name = "txtBoxTestData";
            this.txtBoxTestData.Size = new System.Drawing.Size(342, 41);
            this.txtBoxTestData.TabIndex = 9;
            // 
            // txtBoxTrainData
            // 
            this.txtBoxTrainData.Enabled = false;
            this.txtBoxTrainData.Location = new System.Drawing.Point(318, 35);
            this.txtBoxTrainData.Multiline = true;
            this.txtBoxTrainData.Name = "txtBoxTrainData";
            this.txtBoxTrainData.Size = new System.Drawing.Size(342, 40);
            this.txtBoxTrainData.TabIndex = 8;
            // 
            // btnBrowseTestDtLocal
            // 
            this.btnBrowseTestDtLocal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowseTestDtLocal.Location = new System.Drawing.Point(206, 85);
            this.btnBrowseTestDtLocal.Name = "btnBrowseTestDtLocal";
            this.btnBrowseTestDtLocal.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseTestDtLocal.TabIndex = 7;
            this.btnBrowseTestDtLocal.Text = "Browse";
            this.btnBrowseTestDtLocal.UseVisualStyleBackColor = true;
            this.btnBrowseTestDtLocal.Click += new System.EventHandler(this.btnBrowseTestDtLocal_Click);
            // 
            // btnBrowseTrainDtLocal
            // 
            this.btnBrowseTrainDtLocal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowseTrainDtLocal.Location = new System.Drawing.Point(206, 33);
            this.btnBrowseTrainDtLocal.Name = "btnBrowseTrainDtLocal";
            this.btnBrowseTrainDtLocal.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseTrainDtLocal.TabIndex = 6;
            this.btnBrowseTrainDtLocal.Text = "Browse";
            this.btnBrowseTrainDtLocal.UseVisualStyleBackColor = true;
            this.btnBrowseTrainDtLocal.Click += new System.EventHandler(this.btnBrowseTrainDtLocal_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(42, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Model Build Status";
            // 
            // txtBuildStatus
            // 
            this.txtBuildStatus.Enabled = false;
            this.txtBuildStatus.Location = new System.Drawing.Point(182, 212);
            this.txtBuildStatus.Name = "txtBuildStatus";
            this.txtBuildStatus.Size = new System.Drawing.Size(100, 20);
            this.txtBuildStatus.TabIndex = 4;
            // 
            // btnBuildModel
            // 
            this.btnBuildModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuildModel.Location = new System.Drawing.Point(520, 207);
            this.btnBuildModel.Name = "btnBuildModel";
            this.btnBuildModel.Size = new System.Drawing.Size(140, 23);
            this.btnBuildModel.TabIndex = 2;
            this.btnBuildModel.Text = "Build Model";
            this.btnBuildModel.UseVisualStyleBackColor = true;
            this.btnBuildModel.Click += new System.EventHandler(this.btnBuildModel_Click);
            // 
            // LblTestDataLocation
            // 
            this.LblTestDataLocation.AutoSize = true;
            this.LblTestDataLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTestDataLocation.Location = new System.Drawing.Point(42, 85);
            this.LblTestDataLocation.Name = "LblTestDataLocation";
            this.LblTestDataLocation.Size = new System.Drawing.Size(116, 13);
            this.LblTestDataLocation.TabIndex = 1;
            this.LblTestDataLocation.Text = "Test Data Location";
            // 
            // lblTrainDataLocation
            // 
            this.lblTrainDataLocation.AutoSize = true;
            this.lblTrainDataLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrainDataLocation.Location = new System.Drawing.Point(42, 33);
            this.lblTrainDataLocation.Name = "lblTrainDataLocation";
            this.lblTrainDataLocation.Size = new System.Drawing.Size(120, 13);
            this.lblTrainDataLocation.TabIndex = 0;
            this.lblTrainDataLocation.Text = "Train Data Location";
            // 
            // openFileTrainData
            // 
            this.openFileTrainData.Filter = "\"tsv files (*.tsv)|*.tsv;";
            this.openFileTrainData.Title = "\"Please select  tsv\"";
            // 
            // openFileTestData
            // 
            this.openFileTestData.Filter = "\"tsv files (*.tsv)|*.tsv;";
            this.openFileTestData.Title = "\"Please select  tsv\"";
            // 
            // btnGetDoctype
            // 
            this.btnGetDoctype.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetDoctype.Location = new System.Drawing.Point(58, 272);
            this.btnGetDoctype.Name = "btnGetDoctype";
            this.btnGetDoctype.Size = new System.Drawing.Size(101, 23);
            this.btnGetDoctype.TabIndex = 9;
            this.btnGetDoctype.Text = "Get Doc Type";
            this.btnGetDoctype.UseVisualStyleBackColor = true;
            this.btnGetDoctype.Click += new System.EventHandler(this.btnGetDoctype_Click);
            // 
            // lblModelPath
            // 
            this.lblModelPath.AutoSize = true;
            this.lblModelPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModelPath.Location = new System.Drawing.Point(37, 214);
            this.lblModelPath.Name = "lblModelPath";
            this.lblModelPath.Size = new System.Drawing.Size(81, 13);
            this.lblModelPath.TabIndex = 10;
            this.lblModelPath.Text = "Select Model";
            // 
            // btnSelectModel
            // 
            this.btnSelectModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectModel.Location = new System.Drawing.Point(133, 209);
            this.btnSelectModel.Name = "btnSelectModel";
            this.btnSelectModel.Size = new System.Drawing.Size(99, 23);
            this.btnSelectModel.TabIndex = 11;
            this.btnSelectModel.Text = "Browse";
            this.btnSelectModel.UseVisualStyleBackColor = true;
            this.btnSelectModel.Click += new System.EventHandler(this.btnSelectModel_Click);
            // 
            // openFileModel
            // 
            this.openFileModel.Filter = "\"zip file (*.zip)|*.zip;";
            // 
            // txtSelectedModel
            // 
            this.txtSelectedModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSelectedModel.Location = new System.Drawing.Point(291, 204);
            this.txtSelectedModel.Multiline = true;
            this.txtSelectedModel.Name = "txtSelectedModel";
            this.txtSelectedModel.Size = new System.Drawing.Size(378, 44);
            this.txtSelectedModel.TabIndex = 12;
            // 
            // btnResetBuildModelPage
            // 
            this.btnResetBuildModelPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetBuildModelPage.Location = new System.Drawing.Point(305, 280);
            this.btnResetBuildModelPage.Name = "btnResetBuildModelPage";
            this.btnResetBuildModelPage.Size = new System.Drawing.Size(75, 23);
            this.btnResetBuildModelPage.TabIndex = 14;
            this.btnResetBuildModelPage.Text = "Reset";
            this.btnResetBuildModelPage.UseVisualStyleBackColor = true;
            this.btnResetBuildModelPage.Click += new System.EventHandler(this.btnResetBuildModelPage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtOcrData;
        private System.Windows.Forms.Label lblOcrData;
        private System.Windows.Forms.Label lblDoctype;
        private System.Windows.Forms.TextBox txtDocType;
        private System.Windows.Forms.Label lblConfidence;
        private System.Windows.Forms.TextBox txtConfidence;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnResetGetDocTypePage;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtBoxTestData;
        private System.Windows.Forms.TextBox txtBoxTrainData;
        private System.Windows.Forms.Button btnBrowseTestDtLocal;
        private System.Windows.Forms.Button btnBrowseTrainDtLocal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBuildStatus;
        private System.Windows.Forms.Button btnBuildModel;
        private System.Windows.Forms.Label LblTestDataLocation;
        private System.Windows.Forms.Label lblTrainDataLocation;
        private System.Windows.Forms.OpenFileDialog openFileTrainData;
        private System.Windows.Forms.OpenFileDialog openFileTestData;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txtSaveModelLocation;
        private System.Windows.Forms.Button btnSBrowseModelFolder;
        private System.Windows.Forms.Label lblModelStorePath;
        private System.Windows.Forms.FolderBrowserDialog openFolderModelLocation;
        private System.Windows.Forms.Button btnGetDoctype;
        private System.Windows.Forms.TextBox txtSelectedModel;
        private System.Windows.Forms.Button btnSelectModel;
        private System.Windows.Forms.Label lblModelPath;
        private System.Windows.Forms.OpenFileDialog openFileModel;
        private System.Windows.Forms.Button btnResetBuildModelPage;
    }
}

